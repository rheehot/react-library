import {PureComponent} from "react";

interface AppProp {

}

interface AppState {

}

export default class ${NAME} extends PureComponent<AppProp, AppState> {

    render() {
        return (
            <div className="component-wrap">
            </div>
        )
    }   
}