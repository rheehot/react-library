import * as React from "react";

interface AppProp {

}

interface AppState {

}

export default class ${NAME} extends React.PureComponent<AppProp, AppState> {

    render() {
        return (
            <div className="component-wrap">
            </div>
        )
    }   
}