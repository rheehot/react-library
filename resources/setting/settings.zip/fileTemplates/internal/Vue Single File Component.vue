<template>
    <div class="component-wrap">
        #[[$END$]]#
    </div> 
</template>

<script lang="ts">
import { Vue, Component } from "vue-property-decorator";

@Component({})
export default class ${COMPONENT_NAME} extends Vue {

}
</script>

<style lang="scss" scoped>
    @import "src/study/scss/mixin";

    .component-wrap {
    
    }
</style>