export enum ${NAME}Action {
    ACTION_1,
    ACTION_2
}

const initialState = {};

export default function ${NAME}Reducer(state = initialState, action: {type: ${NAME}Action}) {

    switch(action.type) {
        default:
            return state;
    }
}
