#set($capitalizedFilename = $NAME.substring(0,1).toUpperCase() + $NAME.substring(1))

export enum ${capitalizedFilename}Action {

}

export interface ${capitalizedFilename}State {
 
}

const initialState = {};

export default function ${NAME}Reducer(state: ${capitalizedFilename}State = initialState, action: {type: ${capitalizedFilename}Action}): ${capitalizedFilename}State {

    switch(action.type) {
        default:
            return state;
    }
}
