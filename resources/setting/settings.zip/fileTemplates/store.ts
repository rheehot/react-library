import {combineReducers, createStore} from "redux";
import {devTools} from "../../../store/store";

export interface RootState {
}

export const rootReducer = combineReducers({
});

//@ts-ignore
export const store = createStore(rootReducer, devTools);
