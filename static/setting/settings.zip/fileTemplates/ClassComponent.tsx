import * as React from "react";
import {Component} from "react";
import "./${NAME}.scss";

export default class ${NAME} extends Component {

    render() {
        return (
            <div className="${NAME}-wrap">
            </div>
        )
    }   
}