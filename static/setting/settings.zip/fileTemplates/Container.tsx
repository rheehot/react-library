#set($NOT_CONTAINER_NAME = $NAME.replace("Container", ""))

import * as React from "react"
import {connect} from "react-redux";

export interface ${NOT_CONTAINER_NAME}Prop {

}

function ${NAME}(props: ${NOT_CONTAINER_NAME}Prop) {

    return <${NOT_CONTAINER_NAME} {...props}/>
}

function mapState(rootState: RootState): ${NOT_CONTAINER_NAME}State {
    
    return {
        
    };
}

const mapDispatch = {
};

export default connect(mapState, mapDispatch)(${NAME})