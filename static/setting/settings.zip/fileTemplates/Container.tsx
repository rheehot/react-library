#set($NOT_CONTAINER_NAME = $NAME.replace("Container", ""))

import * as React from "react"
import {RootState} from "../../redux/store";
import {connect} from "react-redux";

interface AppProp {

}

function ${NAME}(props: AppProp) {

    return <${NOT_CONTAINER_NAME}/>
}

function mapState(rootState: RootState) {
    
    return {
        
    }
}

const mapDispatch = {
}

export default connect(mapState, mapDispatch)(${NAME})