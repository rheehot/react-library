import * as React from "react"

interface AppProp {
    
}

export default function ${NAME}(props: AppProp) {

    return (
        <div className="${NAME}-wrap">
        </div>
    )
}