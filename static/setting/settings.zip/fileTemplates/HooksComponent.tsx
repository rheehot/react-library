import * as React from "react"
import "./${NAME}.scss";

interface AppProp {
    
}

export default function ${NAME}(props: AppProp) {

    return (
        <div className="${NAME}-wrap">
        </div>
    )
}