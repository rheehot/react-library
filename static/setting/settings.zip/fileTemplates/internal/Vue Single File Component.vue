<template>
#[[$END$]]#
</template>

<script lang="ts">
import { Vue, Component } from "vue-property-decorator";

@Component({})
export default class ${COMPONENT_NAME} extends Vue {

}
</script>

<style lang="scss" scoped>

</style>