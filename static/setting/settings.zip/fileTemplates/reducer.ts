#set($capitalizedFilename = $NAME.substring(0,1).toUpperCase() + $NAME.substring(1))

import {createAction, handleActions} from "redux-actions";

//Actions
const ACTION1 = "${PROJECT_NAME}/$NAME/ACTION1";

//Action Creators
export const action1 = createAction<${capitalizedFilename}State>(ACTION1);

//state and reducer
export interface ${capitalizedFilename}State {
}

const initialState:${capitalizedFilename}State = {
};

export const reducer = handleActions<${capitalizedFilename}State. any>({

    [ACTION1]: state => ({
    }),

}, initialState);
