#set($capitalizedFilename = $NAME.substring(0,1).toUpperCase() + $NAME.substring(1))

import {createAction, handleActions} from "redux-actions";

//Actions
const ACTION1 = "${PROJECT_NAME}/$NAME/ACTION1";
const ACTION2 = "${PROJECT_NAME}/$NAME/ACTION2";

//Action Creators
export const action1 = createAction(ACTION1);
export const action2 = createAction(ACTION2);

//state and reducer
export interface ${capitalizedFilename}State {
}

const initialState:${capitalizedFilename}State = {
};

export const reducer = handleActions({

    [ACTION1]: (state: ${capitalizedFilename}State) => ({
    }),

    [ACTION2]: (state: ${capitalizedFilename}State) => ({
    }),

}, initialState);
