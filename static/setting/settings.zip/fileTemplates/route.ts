const path = `FIRST_PATH_NAME/$NAME.replace("Routes", "")`;

export const $NAME = [
    {
        path: `path/example`,
        component: Example
    },
];
