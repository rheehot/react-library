import {combineReducers, createStore} from "redux";
import {devTools} from "../../../store/store";

export type RootState = ReturnType<typeof rootReducer>

const rootReducer = combineReducers({
});

//@ts-ignore
export const store = createStore(rootReducer, devTools);
